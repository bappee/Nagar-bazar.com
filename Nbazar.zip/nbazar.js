
var orderProduct = [];
var totalNumber = [];


// all product


document.getElementById("button").addEventListener('click', function () {
    var order = document.getElementById('order')
    var price = document.getElementById('price')
    var Number1 = document.getElementById('number1')
    totalNumber.push(Number1.innerHTML);
    console.log(totalNumber);
    orderProduct.push(price.innerHTML);
    showOrder();
    count();
    sumAarry();
    delivaryBill();
    totalValue();
})

//start here by following above one

document.getElementById("button2").addEventListener('click', function () {
    var order = document.getElementById('order')
    var price2 = document.getElementById('price2')
    var Number2 = document.getElementById('number2')
    orderProduct.push(price2.innerHTML)
    totalNumber.push(Number2.innerHTML);
    console.log(totalNumber);
    showOrder();
    count();
    sumAarry();
    delivaryBill();
    totalValue();

})

document.getElementById("button3").addEventListener('click', function () {
    var order = document.getElementById('order')
    var price = document.getElementById('price3')
    var Number1 = document.getElementById('number3')
    totalNumber.push(Number1.innerHTML);
    console.log(totalNumber);
    orderProduct.push(price.innerHTML);
    showOrder();
    count();
    sumAarry();
    delivaryBill();
    totalValue();
})
document.getElementById("button4").addEventListener('click', function () {
    var order = document.getElementById('order')
    var price = document.getElementById('price4')
    var Number1 = document.getElementById('number4')
    totalNumber.push(Number1.innerHTML);
    console.log(totalNumber);
    orderProduct.push(price.innerHTML);
    showOrder();
    count();
    sumAarry();
    delivaryBill();
    totalValue();
})
document.getElementById("button5").addEventListener('click', function () {
    var order = document.getElementById('order')
    var price = document.getElementById('price5')
    var Number1 = document.getElementById('number5')
    totalNumber.push(Number1.innerHTML);
    console.log(totalNumber);
    orderProduct.push(price.innerHTML);
    showOrder();
    count();
    sumAarry();
    delivaryBill();
    totalValue();
})
document.getElementById("button6").addEventListener('click', function () {
    var order = document.getElementById('order')
    var price = document.getElementById('price6')
    var Number1 = document.getElementById('number6')
    totalNumber.push(Number1.innerHTML);
    console.log(totalNumber);
    orderProduct.push(price.innerHTML);
    showOrder();
    count();
    sumAarry();
    delivaryBill();
    totalValue();
})
document.getElementById("button7").addEventListener('click', function () {
    var order = document.getElementById('order')
    var price = document.getElementById('price7')
    var Number1 = document.getElementById('number7')
    totalNumber.push(Number1.innerHTML);
    console.log(totalNumber);
    orderProduct.push(price.innerHTML);
    showOrder();
    count();
    sumAarry();
    delivaryBill();
    totalValue();
})
document.getElementById("button8").addEventListener('click', function () {
    var order = document.getElementById('order')
    var price = document.getElementById('price8')
    var Number1 = document.getElementById('number8')
    totalNumber.push(Number1.innerHTML);
    console.log(totalNumber);
    orderProduct.push(price.innerHTML);
    showOrder();
    count();
    sumAarry();
    delivaryBill();
    totalValue();
})
document.getElementById("button9").addEventListener('click', function () {
    var order = document.getElementById('order')
    var price = document.getElementById('price9')
    var Number1 = document.getElementById('number9')
    totalNumber.push(Number1.innerHTML);
    console.log(totalNumber);
    orderProduct.push(price.innerHTML);
    showOrder();
    count();
    sumAarry();
    delivaryBill();
    totalValue();
})
document.getElementById("button10").addEventListener('click', function () {
    var order = document.getElementById('order')
    var price = document.getElementById('price10')
    var Number1 = document.getElementById('number10')
    totalNumber.push(Number1.innerHTML);
    console.log(totalNumber);
    orderProduct.push(price.innerHTML);
    showOrder();
    count();
    sumAarry();
    delivaryBill();
    totalValue();
})
document.getElementById("button11").addEventListener('click', function () {
    var order = document.getElementById('order')
    var price = document.getElementById('price11')
    var Number1 = document.getElementById('number11')
    totalNumber.push(Number1.innerHTML);
    console.log(totalNumber);
    orderProduct.push(price.innerHTML);
    showOrder();
    count();
    sumAarry();
    delivaryBill();
    totalValue();
})
document.getElementById("button12").addEventListener('click', function () {
    var order = document.getElementById('order')
    var price = document.getElementById('price12')
    var Number1 = document.getElementById('number12')
    totalNumber.push(Number1.innerHTML);
    console.log(totalNumber);
    orderProduct.push(price.innerHTML);
    showOrder();
    count();
    sumAarry();
    delivaryBill();
    totalValue();
})
document.getElementById("button13").addEventListener('click', function () {
    var order = document.getElementById('order')
    var price = document.getElementById('price13')
    var Number1 = document.getElementById('number13')
    totalNumber.push(Number1.innerHTML);
    console.log(totalNumber);
    orderProduct.push(price.innerHTML);
    showOrder();
    count();
    sumAarry();
    delivaryBill();
    totalValue();
})
document.getElementById("button14").addEventListener('click', function () {
    var order = document.getElementById('order')
    var price = document.getElementById('price14')
    var Number1 = document.getElementById('number14')
    totalNumber.push(Number1.innerHTML);
    console.log(totalNumber);
    orderProduct.push(price.innerHTML);
    showOrder();
    count();
    sumAarry();
    delivaryBill();
    totalValue();
})
document.getElementById("button15").addEventListener('click', function () {
    var order = document.getElementById('order')
    var price = document.getElementById('price15')
    var Number1 = document.getElementById('number15')
    totalNumber.push(Number1.innerHTML);
    console.log(totalNumber);
    orderProduct.push(price.innerHTML);
    showOrder();
    count();
    sumAarry();
    delivaryBill();
    totalValue();
})
document.getElementById("button16").addEventListener('click', function () {
    var order = document.getElementById('order')
    var price = document.getElementById('price16')
    var Number1 = document.getElementById('number16')
    totalNumber.push(Number1.innerHTML);
    console.log(totalNumber);
    orderProduct.push(price.innerHTML);
    showOrder();
    count();
    sumAarry();
    delivaryBill();
    totalValue();
})
document.getElementById("button17").addEventListener('click', function () {
    var order = document.getElementById('order')
    var price = document.getElementById('price17')
    var Number1 = document.getElementById('number17')
    totalNumber.push(Number1.innerHTML);
    console.log(totalNumber);
    orderProduct.push(price.innerHTML);
    showOrder();
    count();
    sumAarry();
    delivaryBill();
    totalValue();
})
document.getElementById("button18").addEventListener('click', function () {
    var order = document.getElementById('order')
    var price = document.getElementById('price18')
    var Number1 = document.getElementById('number18')
    totalNumber.push(Number1.innerHTML);
    console.log(totalNumber);
    orderProduct.push(price.innerHTML);
    showOrder();
    count();
    sumAarry();
    delivaryBill();
    totalValue();
})
document.getElementById("button19").addEventListener('click', function () {
    var order = document.getElementById('order')
    var price = document.getElementById('price19')
    var Number1 = document.getElementById('number19')
    totalNumber.push(Number1.innerHTML);
    console.log(totalNumber);
    orderProduct.push(price.innerHTML);
    showOrder();
    count();
    sumAarry();
    delivaryBill();
    totalValue();
})
document.getElementById("button20").addEventListener('click', function () {
    var order = document.getElementById('order')
    var price = document.getElementById('price20')
    var Number1 = document.getElementById('number20')
    totalNumber.push(Number1.innerHTML);
    console.log(totalNumber);
    orderProduct.push(price.innerHTML);
    showOrder();
    count();
    sumAarry();
    delivaryBill();
    totalValue();
})
document.getElementById("button21").addEventListener('click', function () {
    var order = document.getElementById('order')
    var price = document.getElementById('price21')
    var Number1 = document.getElementById('number21')
    totalNumber.push(Number1.innerHTML);
    console.log(totalNumber);
    orderProduct.push(price.innerHTML);
    showOrder();
    count();
    sumAarry();
    delivaryBill();
    totalValue();
})











//others function

function showOrder() {
    order.innerHTML = '';
    var product = localStorage.getItem('arry')
    orderProduct.forEach(function (item) {
        order.innerHTML+= "<li> " +item+" </li>";
        console.log(product);
    })
}

// function deleteItems(i){
//     orderProduct.splice(i,1)
//     showOrder();
// }

// delete all
 document.getElementById('del').addEventListener('click',function(){
     document.getElementById('order').innerHTML='';
     document.getElementById('charge').innerText='';
     document.getElementById('sum').innerText='';
     document.getElementById('total').innerText='';
     document.getElementById('cc').innerText='';
 })



document.getElementById('orginalOrder').addEventListener('click', function () {
    // var show= document.getElementById('show')
    // var items= orderProduct
    // show.innerHTML=items;
    var appear = document.getElementById('frm')
    appear.style.display = 'block'

})



function count() {
    var orderNumbers = document.getElementById('cc')
    var length = orderProduct.length
    orderNumbers.innerHTML = length;
}

function sumAarry() {
    // var arraySum= totalNumber.reduce((total,current)=>total + current,0);
    var arrayNumber = totalNumber.reduce(function (prev, cur) {
        return (Number(prev) || 0) + (Number(cur) || 0);

    })

    var Sum = document.getElementById('sum');
    Sum.innerHTML = arrayNumber;

    console.log(arrayNumber);
    console.log(totalNumber);
}

function delivaryBill() {
    var delivary = document.getElementById('charge')
    var delivary2 = 0;
    if (totalNumber >= 10)
        delivary2 = 20;

    else {
        delivary2 = 20;
    }


    delivary.innerHTML = delivary2;
    console.log(delivary2);


}

function totalValue() {
    var delivary = document.getElementById('charge').innerText
    var delivaryNumber = parseFloat(delivary)
    var Sum = document.getElementById('sum').innerText
    var SumNumber = parseFloat(Sum);

    var total = document.getElementById('total')
    var totalAmount = SumNumber + delivaryNumber;

    total.innerHTML = totalAmount;
    console.log(totalAmount);


}

//post data to server

var clicked = document.getElementById('msg')
clicked.addEventListener('click', function () {
    const name = document.getElementById('name').value;
    const phone = document.getElementById('phn').value;
    const blok = document.getElementById('blk').value;
    const address = document.getElementById('address').value;
    const total = document.getElementById('total').innerHTML
    const totalItems = document.getElementById('cc').innerHTML
    const summary = { orderProduct, total }
    const orderedMan = { name, phone, blok, address, totalItems, summary }
    console.log(orderedMan);

    document.getElementById('order').innerHTML='';
    document.getElementById('charge').innerText='';
    document.getElementById('sum').innerText='';
    document.getElementById('total').innerText='';
    document.getElementById('cc').innerText='';
    document.getElementById('name').value='';
    document.getElementById('phn').value='';
    document.getElementById('blk').value='';
     document.getElementById('address').value='';

    fetch('http://localhost:3001/orderPlaced', {
        method: 'POST',

        headers: {
            "Content-type": "application/json; charset=UTF-8"
        },
        body: JSON.stringify(orderedMan)
    })
        .then(res => res.json())
        .then(data => {
          
            console.log('order placed', data)
            alert('successfully placed your order')


        })

})





